import pdftotree

print(pdftotree.parse(pdf_file, html_path=None, model_type=None, model_path=None, visualize=False):)